"use client"

import { useState, useEffect } from "react"
import Sidebar from "./components/Sidebar"
import Home from "./pages/Home"
import Projects from "./pages/Projects"
import About from "./pages/About"
import Contact from "./pages/Contact"
import Dashboard from "./pages/Dashboard"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { AnimatePresence } from "framer-motion"
import { ThemeProvider } from "./context/ThemeContext"
import Cursor from "./components/Cursor"
import Loader from "./components/Loader"
import "./App.css"

function App() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    setTimeout(() => {
      setLoading(false)
    }, 2000)
  }, [])

  return (
    <ThemeProvider>
      <Router>
        {loading ? (
          <Loader />
        ) : (
          <div className="flex flex-col md:flex-row h-screen bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-900 dark:to-black text-white transition-colors duration-300">
            <Cursor />
            <Sidebar />
            <main className="flex-1 overflow-y-auto overflow-x-hidden">
              <AnimatePresence mode="wait">
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/about" element={<About />} />
                  <Route path="/projects" element={<Projects />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/contact" element={<Contact />} />
                </Routes>
              </AnimatePresence>
            </main>
          </div>
        )}
      </Router>
    </ThemeProvider>
  )
}

export default App
