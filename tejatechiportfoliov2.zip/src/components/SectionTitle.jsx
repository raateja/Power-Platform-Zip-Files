"use client"

import { motion } from "framer-motion"

const SectionTitle = ({ title, subtitle }) => {
  return (
    <div className="mb-12">
      <motion.h2
        className="text-3xl md:text-4xl font-bold mb-2 bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {title}
      </motion.h2>
      {subtitle && (
        <motion.p
          className="text-slate-400 text-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {subtitle}
        </motion.p>
      )}
      <motion.div
        className="w-20 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mt-4 rounded-full"
        initial={{ width: 0 }}
        animate={{ width: 80 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      />
    </div>
  )
}

export default SectionTitle
