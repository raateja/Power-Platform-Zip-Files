"use client"

import { motion } from "framer-motion"

const SkillCard = ({ icon, title, level, color }) => {
  return (
    <motion.div
      className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700 hover:border-slate-600 transition-all duration-300 group"
      whileHover={{ y: -5, boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)" }}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true, margin: "-50px" }}
    >
      <div className={`text-4xl mb-4 ${color}`}>{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-purple-500 to-cyan-500"
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          transition={{ duration: 1, delay: 0.2 }}
          viewport={{ once: true }}
        />
      </div>
      <div className="mt-2 text-sm text-slate-400">{level}% Proficiency</div>
    </motion.div>
  )
}

export default SkillCard
