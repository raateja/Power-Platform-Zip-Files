"use client"

import { useState, useContext } from "react"
import { Link, useLocation } from "react-router-dom"
import { motion } from "framer-motion"
import { ThemeContext } from "../context/ThemeContext"
import { FaHome, FaUser, FaCode, FaChartBar, FaEnvelope, FaBars, FaTimes, FaSun, FaMoon } from "react-icons/fa"

const Sidebar = () => {
  const { pathname } = useLocation()
  const { theme, toggleTheme } = useContext(ThemeContext)
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { name: "Home", path: "/", icon: <FaHome /> },
    { name: "About", path: "/about", icon: <FaUser /> },
    { name: "Projects", path: "/projects", icon: <FaCode /> },
    { name: "Dashboard", path: "/dashboard", icon: <FaChartBar /> },
    { name: "Contact", path: "/contact", icon: <FaEnvelope /> },
  ]

  const sidebarVariants = {
    open: { x: 0 },
    closed: { x: "-100%" },
  }

  return (
    <>
      <button
        className="md:hidden fixed top-4 left-4 z-50 bg-slate-800 p-3 rounded-full shadow-lg"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <FaTimes /> : <FaBars />}
      </button>

      <motion.div
        className="fixed md:relative w-64 h-full bg-slate-800/80 backdrop-blur-lg p-6 shadow-xl z-40 md:z-auto"
        variants={sidebarVariants}
        initial="closed"
        animate={isOpen ? "open" : "closed"}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        style={{ display: isOpen ? "block" : null }}
        className="md:block fixed top-0 left-0 w-64 h-full bg-slate-800/80 backdrop-blur-lg p-6 shadow-xl z-40 md:z-auto"
      >
        <div className="flex items-center justify-between mb-10">
          <motion.h1
            className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            TejaTechi
          </motion.h1>
          <button onClick={toggleTheme} className="p-2 rounded-full bg-slate-700 hover:bg-slate-600 transition-colors">
            {theme === "dark" ? <FaSun className="text-yellow-300" /> : <FaMoon className="text-slate-300" />}
          </button>
        </div>

        <nav className="flex flex-col space-y-3">
          {navItems.map((item, index) => (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
            >
              <Link
                to={item.path}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                  pathname === item.path
                    ? "bg-gradient-to-r from-purple-600 to-cyan-600 text-white"
                    : "hover:bg-slate-700/50"
                }`}
                onClick={() => setIsOpen(false)}
              >
                <span className="text-lg">{item.icon}</span>
                <span>{item.name}</span>
                {pathname === item.path && (
                  <motion.div
                    className="absolute left-0 w-1 h-8 bg-white rounded-r-full"
                    layoutId="activeNav"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </Link>
            </motion.div>
          ))}
        </nav>

        <div className="absolute bottom-6 left-0 right-0 px-6">
          <div className="flex items-center justify-center p-3 rounded-lg bg-slate-700/50 backdrop-blur-sm">
            <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
            <span className="text-sm text-slate-300">Online & Available</span>
          </div>
        </div>
      </motion.div>
    </>
  )
}

export default Sidebar
