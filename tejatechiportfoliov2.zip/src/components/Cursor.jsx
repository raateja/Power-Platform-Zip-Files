"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

const Cursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [clicked, setClicked] = useState(false)
  const [linkHovered, setLinkHovered] = useState(false)

  useEffect(() => {
    const mouseMove = (e) => {
      setPosition({ x: e.clientX, y: e.clientY })
    }

    const mouseDown = () => {
      setClicked(true)
      setTimeout(() => setClicked(false), 150)
    }

    const checkHovered = () => {
      const hoveredElements = document.querySelectorAll("a:hover, button:hover")
      setLinkHovered(hoveredElements.length > 0)
    }

    const mouseInterval = setInterval(checkHovered, 100)

    window.addEventListener("mousemove", mouseMove)
    window.addEventListener("mousedown", mouseDown)

    return () => {
      window.removeEventListener("mousemove", mouseMove)
      window.removeEventListener("mousedown", mouseDown)
      clearInterval(mouseInterval)
    }
  }, [])

  const variants = {
    default: {
      x: position.x - 16,
      y: position.y - 16,
      height: 32,
      width: 32,
    },
    clicked: {
      height: 14,
      width: 14,
      x: position.x - 7,
      y: position.y - 7,
    },
    linkHovered: {
      height: 60,
      width: 60,
      x: position.x - 30,
      y: position.y - 30,
      backgroundColor: "rgba(255, 255, 255, 0.1)",
      mixBlendMode: "difference",
    },
  }

  return (
    <motion.div
      className="cursor hidden md:block fixed top-0 left-0 rounded-full pointer-events-none z-50 border-2 border-white"
      variants={variants}
      animate={clicked ? "clicked" : linkHovered ? "linkHovered" : "default"}
      transition={{ type: "spring", stiffness: 500, damping: 28, mass: 0.5 }}
    />
  )
}

export default Cursor
