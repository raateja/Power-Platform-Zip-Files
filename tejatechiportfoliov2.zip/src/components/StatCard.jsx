"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { useState, useEffect } from "react"

const StatCard = ({ icon, value, label, duration = 2 }) => {
  const [count, setCount] = useState(0)
  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true,
  })

  useEffect(() => {
    let start = 0
    const end = Number.parseInt(value.toString().replace(/,/g, ""))

    if (inView) {
      const timer = setInterval(() => {
        start += Math.floor(end / (duration * 60))
        if (start >= end) {
          setCount(end)
          clearInterval(timer)
        } else {
          setCount(start)
        }
      }, 16)

      return () => clearInterval(timer)
    }
  }, [inView, value, duration])

  return (
    <motion.div
      ref={ref}
      className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700 text-center"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
    >
      <div className="text-3xl mb-4 text-purple-500">{icon}</div>
      <motion.h3
        className="text-3xl font-bold mb-1"
        initial={{ scale: 0.5 }}
        whileInView={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 100, delay: 0.2 }}
        viewport={{ once: true }}
      >
        {inView ? count.toLocaleString() : 0}
      </motion.h3>
      <p className="text-slate-400">{label}</p>
    </motion.div>
  )
}

export default StatCard
