"use client"

import { motion } from "framer-motion"
import { FaArrowRight, FaGithub, FaLinkedin, FaTwitter } from "react-icons/fa"
import { Link } from "react-router-dom"

const Home = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center p-6 md:p-10 gap-10">
        <motion.div
          className="w-full md:w-1/2 space-y-6"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-block px-3 py-1 bg-slate-800/50 backdrop-blur-sm rounded-full text-sm text-slate-300 mb-2">
            <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            Available for freelance work
          </div>

          <h1 className="text-4xl md:text-6xl font-bold leading-tight">
            Hi, I'm{" "}
            <span className="bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">Teja</span>
            <br />
            Full Stack Developer
          </h1>

          <p className="text-slate-400 text-lg md:text-xl leading-relaxed">
            I build exceptional digital experiences that are fast, accessible, visually appealing, and responsive. Let's
            turn your vision into reality.
          </p>

          <div className="flex flex-wrap gap-4 pt-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link
                to="/projects"
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg font-medium flex items-center gap-2 hover:shadow-lg hover:shadow-purple-500/20 transition-all duration-300"
              >
                View My Work
                <FaArrowRight />
              </Link>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link
                to="/contact"
                className="px-6 py-3 bg-slate-800 border border-slate-700 rounded-lg font-medium hover:bg-slate-700 transition-all duration-300"
              >
                Contact Me
              </Link>
            </motion.div>
          </div>

          <div className="pt-6">
            <p className="text-slate-500 mb-3">Find me on</p>
            <div className="flex gap-4">
              <motion.a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors"
                whileHover={{ y: -3 }}
              >
                <FaGithub />
              </motion.a>
              <motion.a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors"
                whileHover={{ y: -3 }}
              >
                <FaLinkedin />
              </motion.a>
              <motion.a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors"
                whileHover={{ y: -3 }}
              >
                <FaTwitter />
              </motion.a>
            </div>
          </div>
        </motion.div>

        <motion.div
          className="w-full md:w-1/2 relative"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative z-10">
            <div className="w-full h-[400px] md:h-[500px] bg-gradient-to-br from-purple-600/20 to-cyan-600/20 rounded-2xl overflow-hidden border border-slate-700 backdrop-blur-sm">
              <img
                src="/placeholder.svg?height=500&width=500"
                alt="Teja - Full Stack Developer"
                className="w-full h-full object-cover mix-blend-luminosity opacity-80"
              />
            </div>

            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-full blur-3xl opacity-30"></div>
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-full blur-3xl opacity-30"></div>
          </div>

          <div className="absolute top-4 right-4 bg-slate-800/80 backdrop-blur-sm px-4 py-2 rounded-lg border border-slate-700 shadow-xl">
            <div className="text-sm font-medium">Current Status</div>
            <div className="text-green-500 flex items-center gap-1 text-sm">
              <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              Working on exciting projects
            </div>
          </div>

          <div className="absolute bottom-4 left-4 bg-slate-800/80 backdrop-blur-sm px-4 py-2 rounded-lg border border-slate-700 shadow-xl">
            <div className="text-sm font-medium">Tech Stack</div>
            <div className="text-slate-300 text-sm">React, Node.js, MongoDB, Next.js</div>
          </div>
        </motion.div>
      </div>

      <motion.div
        className="py-6 px-6 md:px-10 bg-slate-800/50 backdrop-blur-lg border-t border-slate-700"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">
                5+
              </div>
              <div className="text-slate-400 text-sm md:text-base">Years Experience</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">
                50+
              </div>
              <div className="text-slate-400 text-sm md:text-base">Projects Completed</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">
                30+
              </div>
              <div className="text-slate-400 text-sm md:text-base">Happy Clients</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">
                99%
              </div>
              <div className="text-slate-400 text-sm md:text-base">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default Home
