"use client"

import { motion } from "framer-motion"
import { FaMapMarkerAlt, FaEnvelope, FaPhone, FaGithub, FaLinkedin, FaTwitter } from "react-icons/fa"
import SectionTitle from "../components/SectionTitle"
import ContactForm from "../components/ContactForm"

export default function Contact() {
  const contactInfo = [
    {
      icon: <FaMapMarkerAlt />,
      title: "Location",
      details: "San Francisco, CA",
      color: "text-red-500",
    },
    {
      icon: <FaEnvelope />,
      title: "Email",
      details: "contact@tejatechi.com",
      color: "text-blue-500",
    },
    {
      icon: <FaPhone />,
      title: "Phone",
      details: "+1 (123) 456-7890",
      color: "text-green-500",
    },
  ]

  const socialLinks = [
    { icon: <FaGithub />, url: "https://github.com", name: "GitHub" },
    { icon: <FaLinkedin />, url: "https://linkedin.com", name: "LinkedIn" },
    { icon: <FaTwitter />, url: "https://twitter.com", name: "Twitter" },
  ]

  return (
    <div className="min-h-screen py-10 px-6 md:px-10">
      <div className="max-w-6xl mx-auto space-y-16">
        <SectionTitle title="Contact Me" subtitle="Get in touch with me" />

        {/* Contact Info Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {contactInfo.map((info, index) => (
            <motion.div
              key={index}
              className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700 text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5, boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)" }}
            >
              <div className={`text-4xl mb-4 ${info.color} mx-auto`}>{info.icon}</div>
              <h3 className="text-xl font-bold mb-2">{info.title}</h3>
              <p className="text-slate-300">{info.details}</p>
            </motion.div>
          ))}
        </div>

        {/* Contact Form and Map Section */}
        <div className="grid md:grid-cols-2 gap-10">
          <ContactForm />

          <motion.div
            className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700 h-full"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Find Me On</h3>

            <div className="space-y-6 mb-8">
              {socialLinks.map((link, index) => (
                <motion.a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition-colors"
                  whileHover={{ x: 5 }}
                >
                  <div className="text-2xl">{link.icon}</div>
                  <span>{link.name}</span>
                </motion.a>
              ))}
            </div>

            <div className="aspect-video rounded-lg overflow-hidden border border-slate-700">
              <div className="w-full h-full bg-slate-700 flex items-center justify-center">
                <p className="text-slate-400">Interactive Map Would Be Here</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Call to Action */}
        <motion.div
          className="bg-gradient-to-r from-purple-600/20 to-cyan-600/20 backdrop-blur-lg p-10 rounded-xl border border-slate-700 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold mb-4">Ready to Start a Project?</h3>
          <p className="text-slate-300 mb-6 max-w-2xl mx-auto">
            I'm currently available for freelance work. If you have a project that needs some creative touch, I'd love
            to hear about it.
          </p>
          <motion.button
            className="px-8 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg font-medium hover:shadow-lg hover:shadow-purple-500/20 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Let's Talk
          </motion.button>
        </motion.div>
      </div>
    </div>
  )
}
