"use client"

import { motion } from "framer-motion"
import { FaCode, FaServer, FaMobile, FaDatabase, FaCloud, FaTools } from "react-icons/fa"
import SectionTitle from "../components/SectionTitle"
import SkillCard from "../components/SkillCard"

export default function About() {
  const skills = [
    { icon: <FaCode />, title: "Frontend Development", level: 95, color: "text-blue-500" },
    { icon: <FaServer />, title: "Backend Development", level: 90, color: "text-green-500" },
    { icon: <FaMobile />, title: "Mobile Development", level: 85, color: "text-yellow-500" },
    { icon: <FaDatabase />, title: "Database Management", level: 88, color: "text-red-500" },
    { icon: <FaCloud />, title: "Cloud Services", level: 80, color: "text-purple-500" },
    { icon: <FaTools />, title: "DevOps", level: 75, color: "text-cyan-500" },
  ]

  const experiences = [
    {
      period: "2021 - Present",
      title: "Senior Full Stack Developer",
      company: "TechInnovate Solutions",
      description:
        "Leading development of enterprise web applications using React, Node.js, and AWS. Managing a team of 5 developers and implementing CI/CD pipelines.",
    },
    {
      period: "2019 - 2021",
      title: "Full Stack Developer",
      company: "Digital Crafters",
      description:
        "Developed and maintained multiple client projects using MERN stack. Implemented responsive designs and optimized application performance.",
    },
    {
      period: "2017 - 2019",
      title: "Frontend Developer",
      company: "WebVision Studio",
      description:
        "Created interactive UI components and implemented responsive layouts for various client websites using React and Vue.js.",
    },
  ]

  const education = [
    {
      period: "2015 - 2017",
      degree: "Master's in Computer Science",
      institution: "Tech University",
      description: "Specialized in Web Technologies and Cloud Computing. Graduated with distinction.",
    },
    {
      period: "2011 - 2015",
      degree: "Bachelor's in Computer Engineering",
      institution: "Engineering College",
      description: "Focused on software development and database systems. Participated in multiple hackathons.",
    },
  ]

  return (
    <div className="min-h-screen py-10 px-6 md:px-10">
      <div className="max-w-6xl mx-auto space-y-20">
        {/* About Me Section */}
        <section>
          <SectionTitle title="About Me" subtitle="Get to know me better" />

          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div
              className="relative"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-full h-[400px] bg-gradient-to-br from-purple-600/20 to-cyan-600/20 rounded-2xl overflow-hidden border border-slate-700">
                <img
                  src="/placeholder.svg?height=400&width=400"
                  alt="Teja - Full Stack Developer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-full blur-3xl opacity-30"></div>
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-full blur-3xl opacity-30"></div>
            </motion.div>

            <motion.div
              className="space-y-6"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h3 className="text-2xl font-bold">
                I'm a{" "}
                <span className="bg-gradient-to-r from-purple-500 to-cyan-500 bg-clip-text text-transparent">
                  Full Stack Developer
                </span>{" "}
                with a passion for creating exceptional digital experiences
              </h3>

              <div className="space-y-4 text-slate-300">
                <p>
                  With over 5 years of experience in web development, I specialize in building modern, responsive, and
                  high-performance web applications that deliver exceptional user experiences.
                </p>
                <p>
                  My expertise spans across the entire development stack, from crafting intuitive user interfaces with
                  React and Next.js to building robust backend systems with Node.js and Express. I'm proficient in
                  database management, API development, and cloud deployment.
                </p>
                <p>
                  I'm passionate about staying at the forefront of technology trends and continuously expanding my skill
                  set to deliver cutting-edge solutions that meet and exceed client expectations.
                </p>
              </div>

              <div className="pt-4 grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-slate-400 mb-1">Name</h4>
                  <p className="font-medium">Teja Techi</p>
                </div>
                <div>
                  <h4 className="text-slate-400 mb-1">Email</h4>
                  <p className="font-medium">contact@tejatechi.com</p>
                </div>
                <div>
                  <h4 className="text-slate-400 mb-1">Location</h4>
                  <p className="font-medium">San Francisco, CA</p>
                </div>
                <div>
                  <h4 className="text-slate-400 mb-1">Availability</h4>
                  <p className="font-medium text-green-500">Available for hire</p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Skills Section */}
        <section>
          <SectionTitle title="My Skills" subtitle="What I can do for you" />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <SkillCard key={index} icon={skill.icon} title={skill.title} level={skill.level} color={skill.color} />
            ))}
          </div>
        </section>

        {/* Experience Section */}
        <section>
          <SectionTitle title="Work Experience" subtitle="My professional journey" />

          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                className="relative pl-8 pb-8 border-l-2 border-slate-700 last:border-0 last:pb-0"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-50px" }}
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500"></div>
                <div className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700">
                  <div className="inline-block px-3 py-1 bg-slate-700 rounded-full text-sm text-slate-300 mb-4">
                    {exp.period}
                  </div>
                  <h3 className="text-xl font-bold mb-1">{exp.title}</h3>
                  <p className="text-purple-400 mb-4">{exp.company}</p>
                  <p className="text-slate-400">{exp.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Education Section */}
        <section>
          <SectionTitle title="Education" subtitle="My academic background" />

          <div className="space-y-8">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                className="relative pl-8 pb-8 border-l-2 border-slate-700 last:border-0 last:pb-0"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-50px" }}
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500"></div>
                <div className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700">
                  <div className="inline-block px-3 py-1 bg-slate-700 rounded-full text-sm text-slate-300 mb-4">
                    {edu.period}
                  </div>
                  <h3 className="text-xl font-bold mb-1">{edu.degree}</h3>
                  <p className="text-purple-400 mb-4">{edu.institution}</p>
                  <p className="text-slate-400">{edu.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
