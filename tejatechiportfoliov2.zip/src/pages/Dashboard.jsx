"use client"

import { motion } from "framer-motion"
import { FaUsers, FaCode, FaClock, FaStar } from "react-icons/fa"
import SectionTitle from "../components/SectionTitle"
import StatCard from "../components/StatCard"

export default function Dashboard() {
  const stats = [
    { icon: <FaUsers />, value: 30, label: "Happy Clients" },
    { icon: <FaCode />, value: 50, label: "Projects Completed" },
    { icon: <FaClock />, value: 5, label: "Years Experience" },
    { icon: <FaStar />, value: 15, label: "Awards Received" },
  ]

  const skills = [
    { name: "React", level: 95 },
    { name: "Node.js", level: 90 },
    { name: "JavaScript", level: 95 },
    { name: "TypeScript", level: 85 },
    { name: "MongoDB", level: 80 },
    { name: "Express", level: 85 },
    { name: "Next.js", level: 80 },
    { name: "Tailwind CSS", level: 90 },
  ]

  const recentProjects = [
    { name: "E-Commerce Platform", completion: 100, color: "from-green-500 to-green-600" },
    { name: "Portfolio Website", completion: 100, color: "from-green-500 to-green-600" },
    { name: "Task Management App", completion: 85, color: "from-yellow-500 to-yellow-600" },
    { name: "Weather Dashboard", completion: 70, color: "from-yellow-500 to-yellow-600" },
    { name: "Blog API", completion: 60, color: "from-orange-500 to-orange-600" },
  ]

  return (
    <div className="min-h-screen py-10 px-6 md:px-10">
      <div className="max-w-6xl mx-auto space-y-16">
        <SectionTitle title="Dashboard" subtitle="Overview of my work and skills" />

        {/* Stats Section */}
        <section>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <StatCard key={index} icon={stat.icon} value={stat.value} label={stat.label} />
            ))}
          </div>
        </section>

        {/* Skills and Projects Section */}
        <section className="grid md:grid-cols-2 gap-10">
          {/* Skills */}
          <motion.div
            className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Skills Proficiency</h3>
            <div className="space-y-5">
              {skills.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span>{skill.name}</span>
                    <span>{skill.level}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-purple-500 to-cyan-500"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      transition={{ duration: 1, delay: 0.1 * index }}
                      viewport={{ once: true }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Recent Projects */}
          <motion.div
            className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Recent Projects</h3>
            <div className="space-y-5">
              {recentProjects.map((project, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span>{project.name}</span>
                    <span>{project.completion}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full bg-gradient-to-r ${project.color}`}
                      initial={{ width: 0 }}
                      whileInView={{ width: `${project.completion}%` }}
                      transition={{ duration: 1, delay: 0.1 * index }}
                      viewport={{ once: true }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Activity Chart */}
        <section>
          <motion.div
            className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Yearly Activity</h3>
            <div className="h-64 flex items-end justify-between gap-1">
              {Array.from({ length: 12 }).map((_, index) => {
                const height = Math.floor(Math.random() * 80) + 20
                return (
                  <motion.div
                    key={index}
                    className="bg-gradient-to-t from-purple-600 to-cyan-600 rounded-t-md w-full"
                    initial={{ height: 0 }}
                    whileInView={{ height: `${height}%` }}
                    transition={{ duration: 1, delay: index * 0.05 }}
                    viewport={{ once: true }}
                  />
                )
              })}
            </div>
            <div className="flex justify-between mt-2 text-xs text-slate-400">
              <span>Jan</span>
              <span>Feb</span>
              <span>Mar</span>
              <span>Apr</span>
              <span>May</span>
              <span>Jun</span>
              <span>Jul</span>
              <span>Aug</span>
              <span>Sep</span>
              <span>Oct</span>
              <span>Nov</span>
              <span>Dec</span>
            </div>
          </motion.div>
        </section>

        {/* Testimonials */}
        <section>
          <h3 className="text-2xl font-bold mb-6">Client Testimonials</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2].map((_, index) => (
              <motion.div
                key={index}
                className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl border border-slate-700"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-slate-700 overflow-hidden">
                    <img
                      src={`/placeholder.svg?height=50&width=50`}
                      alt="Client"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Client Name</h4>
                    <p className="text-sm text-slate-400">CEO, Company Name</p>
                  </div>
                  <div className="flex ml-auto">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <FaStar key={i} className="text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-slate-300 italic">
                  "Working with Teja was an absolute pleasure. Their technical expertise, creativity, and attention to
                  detail resulted in a product that exceeded our expectations. Highly recommended!"
                </p>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
