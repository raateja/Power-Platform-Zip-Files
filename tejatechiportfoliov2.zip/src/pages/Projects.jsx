"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import SectionTitle from "../components/SectionTitle"
import ProjectCard from "../components/ProjectCard"

export default function Projects() {
  const [filter, setFilter] = useState("all")

  const projects = [
    {
      id: 1,
      title: "E-Commerce Platform",
      description:
        "A full-featured e-commerce platform with payment integration, user authentication, and admin dashboard.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React", "Node.js", "MongoDB", "Stripe"],
      category: "fullstack",
      github: "https://github.com",
      demo: "https://demo.com",
    },
    {
      id: 2,
      title: "Portfolio Website",
      description: "A modern portfolio website with smooth animations and responsive design.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React", "Framer Motion", "Tailwind CSS"],
      category: "frontend",
      github: "https://github.com",
      demo: "https://demo.com",
    },
    {
      id: 3,
      title: "Task Management App",
      description: "A collaborative task management application with real-time updates and team features.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React", "Firebase", "Redux", "Material UI"],
      category: "fullstack",
      github: "https://github.com",
      demo: "https://demo.com",
    },
    {
      id: 4,
      title: "Weather Dashboard",
      description: "A weather dashboard that displays current and forecasted weather data for multiple locations.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["JavaScript", "Weather API", "Chart.js"],
      category: "frontend",
      github: "https://github.com",
      demo: "https://demo.com",
    },
    {
      id: 5,
      title: "Blog API",
      description: "A RESTful API for a blog platform with authentication, authorization, and CRUD operations.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["Node.js", "Express", "MongoDB", "JWT"],
      category: "backend",
      github: "https://github.com",
      demo: null,
    },
    {
      id: 6,
      title: "Social Media Dashboard",
      description: "A dashboard that aggregates and displays social media metrics from multiple platforms.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React", "D3.js", "Social Media APIs"],
      category: "frontend",
      github: "https://github.com",
      demo: "https://demo.com",
    },
  ]

  const filteredProjects = filter === "all" ? projects : projects.filter((project) => project.category === filter)

  return (
    <div className="min-h-screen py-10 px-6 md:px-10">
      <div className="max-w-6xl mx-auto space-y-10">
        <SectionTitle title="My Projects" subtitle="Check out my recent work" />

        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {["all", "frontend", "backend", "fullstack"].map((category) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-4 py-2 rounded-full capitalize transition-all duration-300 ${
                filter === category
                  ? "bg-gradient-to-r from-purple-600 to-cyan-600 text-white"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>

        <motion.div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" layout transition={{ duration: 0.5 }}>
          {filteredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              title={project.title}
              description={project.description}
              image={project.image}
              tags={project.tags}
              github={project.github}
              demo={project.demo}
            />
          ))}
        </motion.div>

        <div className="flex justify-center mt-10">
          <motion.button
            className="px-6 py-3 bg-slate-800 border border-slate-700 rounded-lg font-medium hover:bg-slate-700 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View More Projects
          </motion.button>
        </div>
      </div>
    </div>
  )
}
