import React from 'react';

export default function Dashboard() {
  return <div className='p-10'>Dashboard Overview</div>;
}