import React from "react";

const Home = () => {
  return (
    <div className="p-10">
      <h1 className="text-4xl font-bold mb-4">Welcome to TejaTechi</h1>
      <p>This is your interactive portfolio dashboard!</p>
    </div>
  );
};

export default Home;