import React from 'react';

export default function Projects() {
  return <div className='p-10'>My Projects</div>;
}