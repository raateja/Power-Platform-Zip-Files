import React from 'react';

export default function About() {
  return <div className='p-10'>About Me</div>;
}