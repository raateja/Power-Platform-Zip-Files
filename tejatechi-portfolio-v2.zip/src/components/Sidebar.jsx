import React from "react";
import { Link, useLocation } from "react-router-dom";

const Sidebar = () => {
  const { pathname } = useLocation();
  const navItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Projects", path: "/projects" },
    { name: "Dashboard", path: "/dashboard" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <div className="w-64 bg-glass p-4 shadow-lg">
      <h1 className="text-2xl font-bold mb-6">TejaTechi</h1>
      <nav className="flex flex-col space-y-3">
        {navItems.map(item => (
          <Link
            key={item.name}
            to={item.path}
            className={`p-2 rounded transition ${
              pathname === item.path ? "bg-white text-black" : "hover:bg-white hover:text-black"
            }`}
          >
            {item.name}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;