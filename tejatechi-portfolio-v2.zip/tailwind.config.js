module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        dark: "#0f172a",
        glass: "rgba(255, 255, 255, 0.1)",
      },
    },
  },
  plugins: [],
};